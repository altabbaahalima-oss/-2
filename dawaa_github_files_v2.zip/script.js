const STORAGE_KEY = "dawaa_app_v2";
const $ = id => document.getElementById(id);
let data = loadData();
let lastReminderMinute = "";

function blankData(){return {patientName:"",beneficiaryPhone:"",emergencyPhone:"",reportEmail:"",medicines:[],takenLog:{}}}
function loadData(){try{return {...blankData(),...JSON.parse(localStorage.getItem(STORAGE_KEY)||"{}")}}catch{return blankData()}}
function saveData(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(data))}catch{}}
function showToast(message){
  const t=$("toast");t.textContent=message;t.classList.add("show");
  clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>t.classList.remove("show"),3000);
}
function showScreen(id){
  document.querySelectorAll(".screen").forEach(s=>s.classList.toggle("active",s.id===id));
  document.querySelectorAll(".step").forEach(s=>s.classList.toggle("active",s.id===({"welcome":"step1","settings":"step2","medicines":"step3"}[id])));
  if(id==="settings")fillSettings();
  if(id==="medicines")renderMedicines();
  window.scrollTo({top:0,behavior:"smooth"});
}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function todayKey(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
function isTaken(id){return data.takenLog[`${todayKey()}_${id}`]===true}
function fillSettings(){
  $("savedPatientName").value=data.patientName||"";
  $("beneficiaryPhone").value=data.beneficiaryPhone||"";
  $("emergencyPhone").value=data.emergencyPhone||"";
  $("reportEmail").value=data.reportEmail||"";
}
function renderMedicines(){
  $("greeting").textContent=data.patientName?`أهلًا ${data.patientName}، إليك جدولك اليومي.`:"أضف دواءك وحدد وقت التذكير المناسب.";
  $("medicineCount").textContent=data.medicines.length;
  $("takenCount").textContent=data.medicines.filter(m=>isTaken(m.id)).length;
  $("todayLabel").textContent=new Date().toLocaleDateString("ar-SA",{weekday:"short",day:"numeric",month:"short"});
  const list=$("medicineList");
  if(!data.medicines.length){
    list.innerHTML='<div class="empty-state"><div class="empty-icon">◷</div><b>جدولك يبدأ من هنا</b><p>أضف أول دواء ليظهر في هذه القائمة.</p></div>';return;
  }
  list.innerHTML=data.medicines.slice().sort((a,b)=>a.time.localeCompare(b.time)).map(m=>{
    const taken=isTaken(m.id);
    return `<article class="medicine-item"><div class="medicine-top"><div><p class="medicine-name">${esc(m.name)}</p><p class="medicine-dose">${esc(m.dose)}</p><p class="medicine-time">◷ ${esc(m.time)}</p></div><span class="${taken?"taken-badge":"pending-badge"}">${taken?"تم تسجيلها":"بانتظارها"}</span></div><div class="medicine-actions"><button class="${taken?"secondary":"primary"}" onclick="toggleTaken('${m.id}')">${taken?"إلغاء التسجيل":"✓ تم أخذ الجرعة"}</button><button class="secondary" onclick="deleteMedicine('${m.id}')">حذف</button></div></article>`;
  }).join("");
}
function toggleTaken(id){const key=`${todayKey()}_${id}`;data.takenLog[key]=!data.takenLog[key];saveData();renderMedicines();showToast(data.takenLog[key]?"تم تسجيل الجرعة لهذا اليوم.":"تم إلغاء تسجيل الجرعة.")}
function deleteMedicine(id){
  const m=data.medicines.find(x=>x.id===id);if(!m||!confirm(`حذف دواء «${m.name}»؟`))return;
  data.medicines=data.medicines.filter(x=>x.id!==id);saveData();renderMedicines();showToast("تم حذف الدواء.");
}
$("settingsForm").addEventListener("submit",e=>{
  e.preventDefault();
  data.patientName=$("savedPatientName").value.trim();
  data.beneficiaryPhone=$("beneficiaryPhone").value.trim();
  data.emergencyPhone=$("emergencyPhone").value.trim();
  data.reportEmail=$("reportEmail").value.trim();
  saveData();showScreen("medicines");showToast("تم حفظ البيانات على هذا الجهاز.");
});
$("medicineForm").addEventListener("submit",e=>{
  e.preventDefault();
  const name=$("medicineName").value.trim(),dose=$("medicineDose").value.trim(),time=$("medicineTime").value;
  if(!name||!dose||!time)return;
  data.medicines.push({id:(crypto.randomUUID?crypto.randomUUID():String(Date.now()+Math.random())),name,dose,time});
  saveData();renderMedicines();e.target.reset();showToast("تمت إضافة الدواء إلى جدولك.");
});
$("callButton").addEventListener("click",()=>{
  const phone=(data.emergencyPhone||"").replace(/[^\d+*#]/g,"");
  if(!phone){showToast("أدخل رقم جهة الاتصال من صفحة التواصل أولًا.");showScreen("settings");return}
  if(confirm(`فتح تطبيق الاتصال للرقم ${data.emergencyPhone}؟`))location.href=`tel:${phone}`;
});
$("reportButton").addEventListener("click",()=>{
  if(!data.reportEmail){showToast("أدخل بريد التقرير من صفحة التواصل أولًا.");showScreen("settings");return}
  const date=new Date().toLocaleDateString("ar-SA");
  const rows=data.medicines.map(m=>`• ${m.name} — ${m.dose} — ${m.time}: ${isTaken(m.id)?"تم تسجيل الجرعة":"لم تُسجل الجرعة"}`);
  const body=`التقرير اليومي لتطبيق دوائي\nالتاريخ: ${date}\nالمستفيد: ${data.patientName||"غير محدد"}\n\n${rows.length?rows.join("\n"):"لا توجد أدوية مضافة."}\n\nملاحظة: التقرير يوضح ما تم تسجيله داخل التطبيق فقط.`;
  location.href=`mailto:${encodeURIComponent(data.reportEmail)}?subject=${encodeURIComponent("التقرير اليومي - دوائي")}&body=${encodeURIComponent(body)}`;
});
function checkReminders(){
  if(!("Notification"in window)||Notification.permission!=="granted")return;
  const now=new Date(),minute=`${todayKey()}_${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}`;
  if(minute===lastReminderMinute)return;
  const due=data.medicines.filter(m=>m.time===minute&&!isTaken(m.id));
  if(!due.length)return;lastReminderMinute=minute;
  due.forEach(m=>{const n=new Notification(`موعد الدواء: ${m.name}`,{body:`${m.dose} — افتح دوائي وسجّل الجرعة بعد أخذها.`,tag:`dawaa-${m.id}-${todayKey()}`});n.onclick=()=>{window.focus();showScreen("medicines")}});
}
function init(){
  $("year").textContent=new Date().getFullYear();
  if(data.patientName||data.medicines.length)fillSettings();
  renderMedicines();
  // يفتح التطبيق دائمًا على صفحة البداية؛ لا يوجد تسجيل دخول.
  showScreen("welcome");
  setInterval(checkReminders,15000);
}
window.showScreen=showScreen;window.toggleTaken=toggleTaken;window.deleteMedicine=deleteMedicine;
init();
